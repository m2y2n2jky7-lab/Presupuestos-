HB PRESUPUESTOS — TALLER DE PORCELÁNICO HB

Esta carpeta contiene la aplicación web.

IMPORTANTE:
El archivo index.html funciona como aplicación web, pero para tener un enlace que puedas abrir desde Safari en el iPhone hay que publicarlo en un servicio de hosting.

index.html = aplicación completa.

El siguiente paso es subir esta carpeta a un hosting estático (por ejemplo Netlify, Vercel o GitHub Pages). No hace falta cambiar el código para ello.
